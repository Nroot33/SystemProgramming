#include <stdio.h>

struct student{
	char* name;
	int number;
};

void swap(struct student *arg1, struct student *arg2){
	struct student temp;
	temp = *arg1;
	*arg1 = *arg2;
	*arg2 = temp;
}

int main(){
	struct student s1;
	s1.name = "Hyo";
	s1.number = 201502049;

	struct student s2;
	s2.name = "JHS";
	s2.number = 0;

	printf("name : %s, number %d\n", s1.name, s1.number);
	printf("name : %s, number %d\n", s2.name, s2.number);

	swap(&s1,&s2);

	printf("swap\n");
	printf("name : %s, number %d\n", s1.name, s1.number);
	printf("name : %s, number %d\n", s2.name, s2.number);

	return 0;
}	
	
